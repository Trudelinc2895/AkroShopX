import asyncio, random, re
from typing import List, Dict
from playwright.async_api import async_playwright

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36",
]

async def search_category(keyword:str, ship_to:str="CA", limit:int=120) -> List[Dict]:
    items: List[Dict] = []
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(user_agent=random.choice(USER_AGENTS))
        page = await context.new_page()
        # Basic search URL; refine as needed
        url = f"https://www.aliexpress.com/wholesale?SearchText={keyword}&ShipToCountry={ship_to}"
        await page.goto(url, timeout=120000)
        await page.wait_for_timeout(4000)
        cards = page.locator("a._3t7zg._2f4Ho")  # selector may change
        count = min(await cards.count(), limit)
        for i in range(count):
            try:
                a = cards.nth(i)
                href = await a.get_attribute("href")
                title = await a.locator("h1,h2,span").first.text_content()
                price_el = a.locator("[class*='price'] span").first
                price_txt = await price_el.text_content()
                image_el = a.locator("img").first
                img = await image_el.get_attribute("src")
                price = float(re.sub(r'[^0-9\.\,]','', price_txt).replace(',', '') or 0.0)
                items.append({
                    "title": title.strip() if title else "Produit AliExpress",
                    "price_source": price or 0.0,
                    "image": img or "",
                    "url": href if href.startswith("http") else f"https:{href}",
                    "source": "AliExpress"
                })
            except Exception:
                continue
        await browser.close()
    return items
