import asyncio, argparse, random, math, yaml, pandas as pd
from typing import List, Dict
from scrapers.aliexpress import search_category as ali_search
from scrapers.wish import search_category as wish_search
from utils.shopify_csv import write_csv

def apply_pricing(cost:float, tiers:list, compare_mult:float)->Dict[str,float]:
    for t in tiers:
        if t["max"] is None or cost <= t["max"]:
            price = cost * (1.0 + t["margin_pct"]/100.0) + t.get("add_fixed",0.0)
            compare = price * compare_mult
            return {"price": round(price,2), "compare_at": round(compare,2), "target_margin_pct": t["margin_pct"]}
    # fallback
    return {"price": round(cost*1.25,2), "compare_at": round(cost*1.25*compare_mult,2), "target_margin_pct": 25.0}

async def gather_products(cfg:dict, max_per_category:int, langs:List[str])->List[Dict]:
    products: List[Dict] = []
    for cat in cfg["categories"]:
        bucket: List[Dict] = []
        keywords = cat["keywords"]
        # split quota across sources
        per_source = math.ceil(max_per_category / ( (1 if not cfg["sources"]["wish"]["enabled"] else 2) ))
        if cfg["sources"]["aliexpress"]["enabled"]:
            results = []
            for kw in keywords:
                results += await ali_search(kw, ship_to=cfg["sources"]["aliexpress"].get("ship_to","CA"), limit=per_source)
            bucket += results[:per_source]
        if cfg["sources"]["wish"]["enabled"]:
            results = []
            for kw in keywords:
                results += await wish_search(kw, limit=per_source)
            bucket += results[:per_source]
        # label category and sample
        for i, it in enumerate(bucket[:max_per_category]):
            it["category"] = cat["name"]
            it["supplier"] = "External"
            it["source_sku"] = f"{it['source'][:3].upper()}-{abs(hash(it['url']))%999999}"
            it["desc"] = f"Produit {it['source']} lié: voir source."
            it["sku"] = f"AKX-{cat['name'][:3].upper()}-{i:03d}"
            it["weight_kg"] = None
            it["google_cat"] = ""
            # pricing
            p = apply_pricing(it.get("price_source",0.0), cfg["pricing"]["tiers"], cfg["pricing"]["compare_at_multiplier"])
            it.update({"price":p["price"], "compare_at":p["compare_at"], "target_margin_pct":p["target_margin_pct"], "cost":it.get("price_source",0.0)})
        products += bucket[:max_per_category]
    return products

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--max-per-category", type=int, default=100)
    ap.add_argument("--lang", default="fr,en")
    ap.add_argument("--out", default="data/akroshopx_products.csv")
    args = ap.parse_args()

    cfg = yaml.safe_load(open(args.config, encoding="utf-8"))
    products = asyncio.run(gather_products(cfg, args.max_per_category, args.lang.split(",")))
    write_csv(args.out, products,
              vendor=cfg["shopify"]["vendor"],
              default_weight_kg=cfg["shopify"]["default_weight"],
              weight_unit=cfg["shopify"]["weight_unit"],
              taxable=cfg["shopify"]["taxable"],
              requires_shipping=cfg["shopify"]["requires_shipping"])
    print(f"Wrote {len(products)} products to {args.out}")

if __name__ == "__main__":
    main()
