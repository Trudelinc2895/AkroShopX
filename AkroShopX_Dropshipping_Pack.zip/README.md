# AkroShopX — Dropshipping Pack (AliExpress + Wish)

Objectif: générer ~100 produits par catégorie depuis AliExpress et Wish, appliquer des règles de prix, produire un CSV Shopify, puis mapper dans DSers/AutoDS.

## 1) Installation
```bash
python -m venv .venv && . .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
playwright install  # si vous utilisez Playwright
```

## 2) Config
Éditez `config.yaml`:
- `categories`: liste des catégories cibles et mots-clés.
- `sources`: activer/désactiver AliExpress/Wish.
- `pricing`: règles de marge par palier.
- `shopify.vendor`: nom de vendeur pour le CSV.

## 3) Exécution
```bash
python pipeline.py --max-per-category 100 --lang fr,en --out data/akroshopx_products.csv
```
Le script va:
1. Scraper chaque source (AliExpress/Wish) par catégorie.
2. Normaliser les données.
3. Appliquer pricing/marge et champs Shopify.
4. Écrire un **CSV importable Shopify**.

> Remarque: AliExpress/Wish ont des protections anti-bot. Playwright aide. Vous pouvez fournir des cookies (voir commentaires dans scrapers).

## 4) Import Shopify
Admin → Produits → Importer → Sélectionner `data/akroshopx_products.csv`

## 5) DSers / AutoDS
- Ouvrez l’app. Utilisez les URLs sources pour **mapper** chaque SKU.
- Importez `dsers_rules.json` comme guide de configuration des règles de prix.

## Légal et technique
- Vérifiez les CGU de chaque plateforme.
- Mettez des délais raisonnables, `--throttle-ms` et User-Agent rotating.
- Basculez vers APIs officielles si vous avez des clés (AliExpress Portals, Wish Partner).
