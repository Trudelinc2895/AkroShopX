import csv, re, html
from typing import List, Dict

SHOPIFY_HEADERS = [
    "Handle","Title","Body (HTML)","Vendor","Type","Tags",
    "Published","Option1 Name","Option1 Value","Option2 Name","Option2 Value","Option3 Name","Option3 Value",
    "Variant SKU","Variant Grams","Variant Inventory Tracker","Variant Inventory Qty","Variant Inventory Policy",
    "Variant Fulfillment Service","Variant Price","Variant Compare At Price","Variant Requires Shipping",
    "Variant Taxable","Variant Barcode","Image Src","Image Position","Image Alt Text","Gift Card","SEO Title",
    "SEO Description","Google Shopping / Google Product Category","Google Shopping / Gender","Google Shopping / Age Group",
    "Google Shopping / MPN","Google Shopping / AdWords Grouping","Google Shopping / AdWords Labels",
    "Google Shopping / Condition","Google Shopping / Custom Product","Google Shopping / Custom Label 0",
    "Google Shopping / Custom Label 1","Google Shopping / Custom Label 2","Google Shopping / Custom Label 3",
    "Google Shopping / Custom Label 4","Variant Image","Variant Weight Unit","Variant Tax Code","Cost per item",
    "Supplier","Source Platform","Source URL","Source SKU","Target Margin %"
]

def slugify(text:str)->str:
    t = re.sub(r'[^a-z0-9]+','-', text.lower())
    return re.sub(r'-+','-', t).strip('-')

def to_rows(products:List[Dict], vendor:str, default_weight_kg:float, weight_unit:str, taxable:bool, requires_shipping:bool)->List[List[str]]:
    rows = []
    for p in products:
        handle = slugify(p['title'])[:60]
        tags = ','.join(sorted(set([p.get('category',''), p.get('source',''), 'akroshopx'])))
        grams = int( (p.get('weight_kg', default_weight_kg) or default_weight_kg) * 1000 )
        rows.append([
            handle,
            p['title'],
            f"<p>{html.escape(p.get('desc',''))}</p>",
            vendor,
            p.get('category',''),
            tags,
            "TRUE",
            "Title","Default","","","","",
            p.get('sku',''),
            str(grams),
            "shopify",
            str(p.get('stock',25)),
            "deny",
            "manual",
            f"{p['price']:.2f}",
            f"{p['compare_at']:.2f}",
            "TRUE" if requires_shipping else "FALSE",
            "TRUE" if taxable else "FALSE",
            "",
            p.get('image',''),
            "1",
            p.get('title',''),
            "FALSE",
            p.get('title','')[:70],
            p.get('desc','')[:150],
            p.get('google_cat',''),
            "",
            "Adult",
            "",
            "",
            "",
            "new",
            "FALSE",
            "",
            "",
            "",
            "",
            "",
            "",
            weight_unit,
            "",
            f"{p.get('cost',0):.2f}",
            p.get('supplier',''),
            p.get('source',''),
            p.get('url',''),
            p.get('source_sku',''),
            f"{p.get('target_margin_pct',0):.2f}"
        ])
    return rows

def write_csv(path:str, products:List[Dict], **shopify):
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(SHOPIFY_HEADERS)
        for row in to_rows(products, **shopify):
            w.writerow(row)
